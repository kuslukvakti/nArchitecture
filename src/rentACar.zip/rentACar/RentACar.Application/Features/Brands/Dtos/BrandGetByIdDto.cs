﻿namespace RentACar.Application.Features.Brands.Dtos
{
    public class BrandGetByIdDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
